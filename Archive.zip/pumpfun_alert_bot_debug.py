
import requests
import time
import json
from datetime import datetime

API_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJub25jZSI6IjI5YzM4Y2U0LTVjODItNDRkMi1hODMxLTlhYzNiMDNlOGVkMSIsIm9yZ0lkIjoiNDQ2Nzk0IiwidXNlcklkIjoiNDU5NjkxIiwidHlwZUlkIjoiYWU0NDQyM2EtMTM5NS00YmNlLWFjYmItMTM1ZDU5NmIzMmMwIiwidHlwZSI6IlBST0pFQ1QiLCJpYXQiOjE3NDcxMjU3NDgsImV4cCI6NDkwMjg4NTc0OH0.dPwYvDwGR5M07zy__R-ckIRFOfzCvQtou9zSxgoDHf0"
TELEGRAM_TOKEN = "7521960876:AAH_goAxPdzbInquIvbaYpd_6h0jYkJAO4k"
CHAT_ID = "7604145219"

MEMORY_FILE = "token_memory.json"
MARKETCAP_THRESHOLD = 60000
PROMETTEUR_THRESHOLD = 70000
STEP_ALERT = 10000
API_URL = "https://solana-gateway.moralis.io/token/mainnet/exchange/pumpfun/graduated"

headers = {
    "accept": "application/json",
    "X-API-Key": API_KEY
}

def load_memory():
    try:
        with open(MEMORY_FILE, "r") as f:
            return json.load(f)
    except:
        return {}

def save_memory(memory):
    with open(MEMORY_FILE, "w") as f:
        json.dump(memory, f)

def send_telegram_alert(token, market_cap):
    name = token.get("name") or "N/A"
    symbol = token.get("symbol") or "N/A"
    mint = token.get("tokenAddress")
    price = token.get("priceUsd")
    liquidity = token.get("liquidity")
    link = f"https://pump.fun/{mint}"

    message = (
        f"🚨 Token Pump Alert 🚨\n"
        f"Name: {name}\n"
        f"Symbol: {symbol}\n"
        f"Market Cap: ${{round(market_cap):,}}\n"
        f"Price: ${{price}}\n"
        f"Liquidity: {liquidity}\n"
        f"🔗 {link}"
    )

    if market_cap >= PROMETTEUR_THRESHOLD:
        message += "\n🔥 Prometteur !"

    url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
    data = {
        "chat_id": CHAT_ID,
        "text": message
    }
    requests.post(url, data=data)

def check_tokens():
    memory = load_memory()
    params = {"limit": 100}
    try:
        res = requests.get(API_URL, headers=headers, params=params)
        if res.status_code != 200:
            print(f"Erreur Moralis : {res.status_code}")
            return

        tokens = res.json().get("result", [])
        for token in tokens:
            try:
                mint = token.get("tokenAddress")
                price = float(token.get("priceUsd") or 0)
                liquidity = float(token.get("liquidity") or 0)
                market_cap = price * liquidity

                print(f"[{datetime.now().strftime('%H:%M:%S')}] Token: {token.get('symbol')} | Price: {price} | Liquidity: {liquidity} | MC: ${round(market_cap):,}")

                if market_cap < MARKETCAP_THRESHOLD:
                    continue

                previous_cap = memory.get(mint, 0)
                if mint not in memory or (market_cap - previous_cap) >= STEP_ALERT:
                    send_telegram_alert(token, market_cap)
                    memory[mint] = market_cap
            except Exception as e:
                print(f"Erreur de token: {e}")

        save_memory(memory)
        print(f"[{datetime.now().strftime('%H:%M:%S')}] ✅ Scan terminé")
    except Exception as e:
        print(f"Erreur globale : {e}")

# Boucle principale toutes les 1 minute
while True:
    check_tokens()
    time.sleep(60)
